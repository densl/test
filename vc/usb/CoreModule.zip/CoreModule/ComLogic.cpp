
#pragma once
#include "stdafx.h"
#include "ComLogic.h"

ComLogic::ComLogic()
{
	
}
ComLogic::~ComLogic()
{

}


//basic function
DWORD ComLogic::getMaxUsb()
{
	return mLogic.getMaxUsb();
}
void  ComLogic::setPortIndex(DWORD index)
{
	mLogic.setPortIndex(index);
}
DWORD ComLogic::getPortNumber()
{
	return mLogic.getPortNumber();
}
DWORD ComLogic::getPortDesc(CString& str)
{
	return mLogic.getPortDesc(str);
}

void  ComLogic::closePrinter()
{
	return mLogic.closePrinter();
}
BOOL  ComLogic::isPrinterAvailable()
{
	return mLogic.isAvailable();
}
BOOL ComLogic::openPrinter(char *portName)
{
	mLogic.setPortName(portName);
	return mLogic.isAvailable();
}

DWORD ComLogic::controlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return mLogic.controlIo(dwIoControlCode, inBuf, inLen, outBuf, outLen);
}
DWORD ComLogic::controlIowithTime(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout)
{
	return mLogic.controlIowithTime(dwIoControlCode, inBuf, inLen, outBuf, outLen, timeout);

}
DWORD ComLogic::readBuf(LPVOID buf, DWORD dwLen)
{
	return mLogic.readBuf(buf, dwLen);
}
DWORD ComLogic::writeBuf(LPVOID buf, DWORD dwLen)
{
	return mLogic.writeBuf(buf, dwLen);
}
DWORD ComLogic::readBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{
	return mLogic.readBufwithTime(buf, dwLen, timeout);
}
DWORD ComLogic::writeBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{
	return mLogic.writeBufwithTime(buf, dwLen, timeout);
}

DWORD ComLogic::unicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte)
{
	return mLogic.unicodeToUTF8(lpWideCharStr, ccWideChar, lpMuttiByteStr, cbMultiByte);
}
DWORD ComLogic::strToHexArray(LPVOID inBuf, LPVOID outBuf)
{
	return mLogic.strToHexArray(inBuf, outBuf);
}
DWORD ComLogic::utf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar)
{
	return mLogic.utf8ToUnicode(lpMuttiByteStr, cbMultiByte, lpWideCharStr, ccWideChar);
}

//
DWORD ComLogic::enumPrinter(CString& str)
{
	return mLogic.enumPrinter(str);
}
byte  ComLogic::getStdStatus()
{
	return mLogic.getStdStatus();
}
DWORD ComLogic::getStdId(CString& str)
{
	return mLogic.getStdId(str);
}

DWORD ComLogic::sendData(char *buf)
{
	return mLogic.sendData(buf);
}
DWORD ComLogic::sendCmd(char *buf)
{
	return mLogic.sendCmd(buf);
}
DWORD ComLogic::sendCmdLen(char *buf, DWORD cmdLen)
{
	return mLogic.sendCmdLen(buf, cmdLen);
}
DWORD ComLogic::sendDataLen(char *buf, DWORD len)
{
	return mLogic.sendDataLen(buf, len);
}

DWORD ComLogic::recvBuf(char *buf, DWORD timeout)
{
	return mLogic.recvBuf(buf, timeout);
}
DWORD ComLogic::recvBufLen(char *buf, DWORD len, DWORD timeout)
{
	return mLogic.recvBufLen(buf, len, timeout);
}


DWORD ComLogic::recvString(CString& str, DWORD times)
{
	return mLogic.recvString(str, times);
}
DWORD ComLogic::recvBarCode(CString& str, DWORD times)
{
	return mLogic.recvBarCode(str, times);
}

DWORD ComLogic::getVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return mLogic.getVendorIo(inBuf, inLen, outBuf, outLen);
}
DWORD ComLogic::setVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return mLogic.setVendorIo(inBuf, inLen, outBuf, outLen);
}

//common functions
DWORD ComLogic::fillEmpty(char *buf, DWORD len)
{
	return mLogic.fillEmpty(buf, len);
}