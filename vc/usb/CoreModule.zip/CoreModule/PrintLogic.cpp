
#pragma once
#include "stdafx.h"
#include "PrintLogic.h"

PrinterLogic::PrinterLogic()
{
	//middleware = Middleware();
}
PrinterLogic::~PrinterLogic()
{

}
void PrinterLogic::closePrinter()
{
	middleware.uClose();
}
BOOL PrinterLogic::openPrinter(char *portName)
{
	middleware.setPortName(portName);
	return middleware.isAvailable();
}
byte PrinterLogic::getStdStatus()
{
	return middleware.getStdStatus();
}
BSTR PrinterLogic::enumPrinter()
{
	DWORD ret = 0;
	CString temp;
	temp.Empty();

	ret = middleware.enumPrinter(temp);

	return temp.AllocSysString();
}
DWORD PrinterLogic::PaperCut()
{
	return middleware.sendCmd("1D58");
}
DWORD PrinterLogic::PaperFeed()
{
	return middleware.sendCmd("1D0415");
}
DWORD PrinterLogic::setPageLength(DOUBLE len)
{
	DWORD m_ErrorCode = 0;
	DWORD mLen = (DWORD)(360 * len);

	if ( mLen == 0 || mLen>>16 > 0)
	{
		return m_ErrorCode;
	}
	byte hbyte = (byte) ( (mLen&0xFF00) >>8 );
	byte lbyte = (byte) (mLen & 0xFF);

	char cmdToSend[1024] = {0};
	sprintf_s(cmdToSend, "1D040C%02X%02X", lbyte, hbyte);

	return middleware.sendCmd(cmdToSend);
}
BSTR PrinterLogic::getBarCode()
{
	BSTR m_ErrorCode = NULL;
	DWORD ret = 0;
	CString barCode;

	ret = middleware.sendCmd("1D534C44");
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	Sleep(100);

	//3seconds
	ret = middleware.recvBarCode(barCode, 30);

	return barCode.AllocSysString();
}