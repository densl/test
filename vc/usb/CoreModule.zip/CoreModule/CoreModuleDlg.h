
// CoreModuleDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"


// CCoreModuleDlg �Ի���
class CCoreModuleDlg : public CDialogEx
{
// ����
public:
	CCoreModuleDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_COREMODULE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	BOOL PreTranslateMessage(MSG* pMsg);
public:
	CEdit m_output;
	afx_msg void OnBnClickedTest();
	CEdit m_input;
	afx_msg void OnBnClickedOpen();
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedSend2();
	afx_msg void OnBnClickedRecv();
	afx_msg void OnBnClickedClose();
	void setOutPutStatic(LPCTSTR str);
	void setOutPut(LPCTSTR str);
};
