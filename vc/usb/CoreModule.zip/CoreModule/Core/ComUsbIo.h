
#pragma once

class ComUsbIo{
public:
	ComUsbIo();
	~ComUsbIo();
private:
	HANDLE g_handle;
	HANDLE getHandle();
public:
	void setHandle(HANDLE mHandle);
	DWORD portControlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout);
	DWORD portSend(LPVOID buf, DWORD dwLen, DWORD mTime);
	DWORD portRecv(LPVOID buf, DWORD dwLen, DWORD mTime);
};