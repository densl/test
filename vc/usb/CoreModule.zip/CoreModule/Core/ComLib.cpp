
#include "stdafx.h"
#include "ComLib.h"


ComLib::ComLib()
{

}
ComLib::~ComLib()
{

}


// L"1234"  ->  "1234"
DWORD ComLib::unicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte)
{
	if (lpWideCharStr == NULL || ccWideChar < 1)
		return 0;

	return WideCharToMultiByte(CP_UTF8, 0, lpWideCharStr, ccWideChar, lpMuttiByteStr, cbMultiByte, NULL, 0);
}

// 313233  ->  "123"
DWORD ComLib::strToHexArray(LPVOID inBuf, LPVOID outBuf)
{
	DWORD len = strlen( (char*)inBuf );
	byte *ibuf = (byte*)inBuf;
	byte *oBuf = (byte*)outBuf;
	// shield
	if ( ((len&0x01) == 1) || inBuf == NULL || outBuf == NULL)
		return 0;

	CHAR temp = 0;
	DWORD index = 0;
	byte hextemp = 0;
	for (WORD i=0; i<len; i++)
	{
		hextemp = ibuf[i];
		if (hextemp >= 'a' && hextemp <= 'f')
			hextemp = hextemp - 'a' + 10;
		if (hextemp >= 'A' && hextemp <= 'F')
			hextemp = hextemp - 'A' + 10;
		if (hextemp >= '0' && hextemp <= '9')
			hextemp = hextemp - '0';

		if ( 0 == (i&0x1) )//even
		{
			temp = 0;
			temp = hextemp << 4;
		}
		else
		{//odd
			temp += hextemp;
			oBuf[index++] = temp;
		}
	}
	return index;
}

// "1234"  ->  L"1234"
DWORD ComLib::utf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar)
{
	if (lpMuttiByteStr == NULL || cbMultiByte < 1)
		return 0;

	return MultiByteToWideChar(CP_UTF8, 0, lpMuttiByteStr, cbMultiByte, lpWideCharStr, ccWideChar);
}

//  "12\x00k"  --> "12 k"
DWORD ComLib::fillEmpty(char *buf, DWORD len)
{
	DWORD count = 0;
	for (DWORD i=0; i<len; i++)
	{
		if (buf[i] == 0)
		{
			buf[i] = 0x20;
			count++;
		}
	}
	return count;
}