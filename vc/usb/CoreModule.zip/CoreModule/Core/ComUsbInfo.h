
#pragma once

typedef struct USBREGINFO UsbRegInfo;

struct USBREGINFO{
	//unsigned int count;
	unsigned int index;
	unsigned int portNumber;
	unsigned int pid;
	unsigned int vid;
	TCHAR portInstance[1024];
	TCHAR portDesc[1024];
	TCHAR portPath[1024];
	struct USBREGINFO *next;
};

class ComUsbInfo{
public:
	ComUsbInfo();
	~ComUsbInfo();	
public:
	DWORD getUsbInfo(UsbRegInfo *mUsbRegInfo);
	void releaseUsbInfo();
};

// usages
//UsbRegInfo rtn;
//ComUsbInfo test = ComUsbInfo();
//test.getUsbInfo(&rtn);