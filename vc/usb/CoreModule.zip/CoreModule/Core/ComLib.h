
#pragma once

class ComLib{
public:
	ComLib();
	~ComLib();
public:
	DWORD unicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte);
	DWORD strToHexArray(LPVOID inBuf, LPVOID outBuf);
	DWORD utf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar);
	DWORD fillEmpty(char *buf, DWORD len);
};