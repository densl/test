
#include "stdafx.h"
#include "ComUsbIo.h"

static void setError(char *msg);


ComUsbIo::ComUsbIo()
{
	g_handle = INVALID_HANDLE_VALUE;
}
ComUsbIo::~ComUsbIo()
{

}

HANDLE ComUsbIo::getHandle()
{
	return g_handle;
}

void ComUsbIo::setHandle(HANDLE mHandle)
{
	g_handle = mHandle;
}
DWORD ComUsbIo::portControlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED m_EvtOvlp;
	memset(&m_EvtOvlp, 0, sizeof(OVERLAPPED));	


	//get usb handle
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<DeviceIo> Invalid handle.");
		return m_ErrorCode;
	}

	//device io control
	m_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn = DeviceIoControl(mHandle, dwIoControlCode, inBuf, inLen, outBuf, outLen, &dwSize, &m_EvtOvlp);	
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<DeviceIo> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(m_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(m_EvtOvlp.hEvent,timeout);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&m_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<DeviceIo> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(m_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(m_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(m_EvtOvlp.hEvent);
	return dwSize;
}
DWORD ComUsbIo::portRecv(LPVOID buf, DWORD dwLen, DWORD mTime)
{

	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED mr_EvtOvlp;
	memset(&mr_EvtOvlp, 0, sizeof(OVERLAPPED));	

	//check options **************************
	if (dwLen == 0 || buf == NULL)
	{
		setError("<Read> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle **************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Read> Invalid handle.");
		return m_ErrorCode;
	}

	//read fp **************************
	mr_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("ReadEvent"));
	DWORD rtn = ReadFile(mHandle,buf,dwLen,&dwSize,&mr_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Read> Create read event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mr_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mr_EvtOvlp.hEvent, mTime);
	if (rtn != WAIT_OBJECT_0)
	{
		return 0;
	}

	//get result **************************
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mr_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Read> GetOverlppedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mr_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms 
			WaitForSingleObject(mr_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mr_EvtOvlp.hEvent);
	return dwSize;
}
DWORD ComUsbIo::portSend(LPVOID buf, DWORD dwLen, DWORD mTime)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved write data length

	OVERLAPPED mw_EvtOvlp;
	memset(&mw_EvtOvlp, 0, sizeof(OVERLAPPED));	

	char *tempstr = (char*)buf;
	DWORD templen = strlen(tempstr);
	//check params ********************************
	if (buf == NULL || templen == 0)
	{
		setError("<Write> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle ********************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Write> Invalid handle.");
		return m_ErrorCode;
	}

	//write fp
	mw_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn =WriteFile(mHandle,buf,dwLen,&dwSize,&mw_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Write> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mw_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mw_EvtOvlp.hEvent,mTime);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mw_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Write> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mw_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(mw_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mw_EvtOvlp.hEvent);
	return dwSize;
}


static void setError(char *msg)
{

}
