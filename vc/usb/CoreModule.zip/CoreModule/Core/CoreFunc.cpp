
#include "stdafx.h"
#include "CoreFunc.h"

#include "SetupAPI.h"
#include <initguid.h>
#pragma comment(lib, "SetupApi")

DEFINE_GUID(USB_PRINTER,0x28d78fad, 0x5a12, 0x11D1, 0xae, 0x5b, 0x00, 0x00, 0xf8, 0x03, 0xa8, 0xc2);

CoreFunc::CoreFunc()
{
	g_portIndex = 0;
	memset(g_portName, 1024, 0);

	setRegEnv();
	g_handle = openDevice();
}
CoreFunc::~CoreFunc()
{

}


//private
DWORD CoreFunc::getUsbPath(CString& str)
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#");
	TCHAR *keyValue = _T("SymbolicLink");

	TCHAR strValue[MAX_PATH];
	DWORD retLen = MAX_PATH * sizeof(TCHAR);
	memset(strValue, 0, retLen);


	ret = getRegValue(keyName, keyValue, strValue, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	str = strValue;
	return ret;
}
DWORD CoreFunc::getUsbInstance(CString& str)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	TCHAR *keyName = _T("SYSTEM\\CurrentControlSet\\Services\\usbprint\\Enum");
	CString strIndex; //saved index
	strIndex.Format(_T("%d"), getPortIndex());

	TCHAR strInstance[MAX_PATH];
	DWORD retLen = MAX_PATH * sizeof(TCHAR);
	memset(strInstance, 0, retLen);

	ret = getRegValue(keyName, strIndex, strInstance, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	str = strInstance;
	return ret;
}

DWORD CoreFunc::setRegEnv()
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	CString mInstance;
	ret = getUsbInstance(mInstance);

	mInstance.Replace(_T('\\'), _T('#'));
	CString strTpl = _T("##?#replacement#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}");
	strTpl.Replace(_T("replacement"), mInstance);


	g_regEnv = _T("SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\{28d78fad-5a12-11d1-ae5b-0000f803a8c2}\\")+strTpl;

	return ret;
}
DWORD CoreFunc::getRegValue(LPCTSTR keyName, LPCTSTR keyValue, LPVOID regValue, DWORD len)
{	
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	//open enum key
	HKEY hKey;
	ret = RegOpenKeyExW(HKEY_LOCAL_MACHINE,keyName,0,KEY_READ,&hKey);
	if( ERROR_SUCCESS !=  ret)
	{
		return m_ErrorCode;
	}

	//get usb printer count
	DWORD retLen = len;
	ret = RegQueryValueExW(hKey,keyValue,NULL,NULL,(BYTE*)regValue,&retLen);
	RegCloseKey(hKey);
	if( ERROR_SUCCESS != ret)
	{	
		return m_ErrorCode;
	}

	return retLen;
}

HANDLE CoreFunc::getHandle()
{
	return g_handle;
}
void CoreFunc::setError(char *str)
{

}
void  CoreFunc::uSetPortIndex(DWORD index)
{
	g_portIndex = index;

	setRegEnv();
	//g_handle = openDevice();
}
DWORD CoreFunc::getPortIndex()
{
	return g_portIndex;
}
HANDLE CoreFunc::openDevice()
{
	HANDLE m_ErrorCode = INVALID_HANDLE_VALUE;
	DWORD ret = 0;
	CString strPath;
	strPath.Empty();

	CStringA portname = g_portName;
	portname.MakeUpper();

	g_handle = INVALID_HANDLE_VALUE;

	if ( strlen(g_portName) == 0 )
	{
		getUsbPath(strPath);
	}

	if (strPath.IsEmpty() && portname.Find("USB") >= 0)
	{
		portname.Trim("USB");
		DWORD num = (DWORD)_atoi64(portname);
		if (num == 0)
			return m_ErrorCode;

		for (DWORD i=0; i<uGetMaxUsb(); i++)
		{
			uSetPortIndex(i);
			if (uGetPortNum() == num)
			{
				getUsbPath(strPath);
				break;
			}
		}
	}
	//lpt
	if (strPath.IsEmpty() )
	{
		strPath.Format(_T("%s"), portname);
	}

	//open device
	HANDLE usbHandle = CreateFileW(strPath,
		GENERIC_READ|GENERIC_WRITE, 
		FILE_SHARE_WRITE | FILE_SHARE_READ, 
		NULL, //must be NULL
		OPEN_EXISTING, //must be OPEN_EXISTING
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED , 
		NULL);

	return usbHandle;
}


//export
DWORD CoreFunc::uGetMaxUsb()
{	
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	TCHAR *keyName = _T("SYSTEM\\CurrentControlSet\\Services\\usbprint\\Enum");
	TCHAR *keyValue = _T("Count");
	DWORD maxNum = 0;
	DWORD len = sizeof(DWORD);

	ret = getRegValue(keyName, keyValue, &maxNum, len);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return maxNum;
}
DWORD CoreFunc::uGetPortNum()
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#\\Device Parameters");
	TCHAR *keyValue = _T("Port Number");

	DWORD portNum = 0;
	DWORD retLen = sizeof(DWORD);


	ret = getRegValue(keyName, keyValue, &portNum, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return portNum;
}
DWORD CoreFunc::uGetPortDesc(CString& str)
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#\\Device Parameters");
	TCHAR *keyValue = _T("Port Description");

	TCHAR strValue[MAX_PATH];
	DWORD retLen = MAX_PATH * sizeof(TCHAR);
	memset(strValue, 0, retLen);


	ret = getRegValue(keyName, keyValue, strValue, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	str = strValue;
	return ret;
}

void CoreFunc::uClose()
{
	HANDLE handle = getHandle();
	if (handle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(handle);
	}
	g_handle = INVALID_HANDLE_VALUE;
}
BOOL CoreFunc::uIsAvailable()
{
	return ( getHandle() == INVALID_HANDLE_VALUE ) ? FALSE : TRUE;
}
void CoreFunc::uSetPortName(char *portName)
{
	DWORD len = strlen(portName);

	memset(g_portName, 0, 1024);
	memcpy(g_portName, portName, len>1024 ? 1023 : len);

	uClose();
	setRegEnv();
	g_handle = openDevice();
}

DWORD CoreFunc::uControlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED m_EvtOvlp;
	memset(&m_EvtOvlp, 0, sizeof(OVERLAPPED));	


	//get usb handle
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<DeviceIo> Invalid handle.");
		return m_ErrorCode;
	}

	//device io control
	m_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn = DeviceIoControl(mHandle, dwIoControlCode, inBuf, inLen, outBuf, outLen, &dwSize, &m_EvtOvlp);	
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<DeviceIo> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(m_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(m_EvtOvlp.hEvent,100);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&m_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<DeviceIo> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(m_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(m_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(m_EvtOvlp.hEvent);
	return dwSize;
}
DWORD CoreFunc::uControlIowithTime(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED m_EvtOvlp;
	memset(&m_EvtOvlp, 0, sizeof(OVERLAPPED));	


	//get usb handle
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<DeviceIo> Invalid handle.");
		return m_ErrorCode;
	}

	//device io control
	m_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn = DeviceIoControl(mHandle, dwIoControlCode, inBuf, inLen, outBuf, outLen, &dwSize, &m_EvtOvlp);	
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<DeviceIo> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(m_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(m_EvtOvlp.hEvent,timeout);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&m_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<DeviceIo> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(m_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(m_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(m_EvtOvlp.hEvent);
	return dwSize;
}
DWORD CoreFunc::uRead(LPVOID buf, DWORD dwLen)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED mr_EvtOvlp;
	memset(&mr_EvtOvlp, 0, sizeof(OVERLAPPED));	

	//check options **************************
	if (dwLen == 0 || buf == NULL)
	{
		setError("<Read> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle **************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Read> Invalid handle.");
		return m_ErrorCode;
	}

	//read fp **************************
	mr_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("ReadEvent"));
	DWORD rtn = ReadFile(mHandle,buf,dwLen,&dwSize,&mr_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Read> Create read event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mr_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mr_EvtOvlp.hEvent,100);

	//get result **************************
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mr_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Read> GetOverlppedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mr_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms 
			WaitForSingleObject(mr_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mr_EvtOvlp.hEvent);
	return dwSize;
}
DWORD CoreFunc::uReadwithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{

	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved recv data length

	OVERLAPPED mr_EvtOvlp;
	memset(&mr_EvtOvlp, 0, sizeof(OVERLAPPED));	

	//check options **************************
	if (dwLen == 0 || buf == NULL)
	{
		setError("<Read> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle **************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Read> Invalid handle.");
		return m_ErrorCode;
	}

	//read fp **************************
	mr_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("ReadEvent"));
	DWORD rtn = ReadFile(mHandle,buf,dwLen,&dwSize,&mr_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Read> Create read event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mr_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mr_EvtOvlp.hEvent, timeout);
	if (rtn != WAIT_OBJECT_0)
	{
		return 0;
	}

	//get result **************************
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mr_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Read> GetOverlppedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mr_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms 
			WaitForSingleObject(mr_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mr_EvtOvlp.hEvent);
	return dwSize;
}
DWORD CoreFunc::uWrite(LPVOID buf, DWORD dwLen)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved write data length

	OVERLAPPED mw_EvtOvlp;
	memset(&mw_EvtOvlp, 0, sizeof(OVERLAPPED));	

	char *tempstr = (char*)buf;
	DWORD templen = strlen(tempstr);
	//check params ********************************
	if (buf == NULL || templen == 0)
	{
		setError("<Write> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle ********************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Write> Invalid handle.");
		return m_ErrorCode;
	}

	//write fp
	mw_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn =WriteFile(mHandle,buf,dwLen,&dwSize,&mw_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Write> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mw_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mw_EvtOvlp.hEvent,100);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mw_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Write> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mw_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(mw_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mw_EvtOvlp.hEvent);
	return dwSize;
}
DWORD CoreFunc::uWritewithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{
	DWORD m_ErrorCode = 0;
	DWORD dwSize = 0; //saved write data length

	OVERLAPPED mw_EvtOvlp;
	memset(&mw_EvtOvlp, 0, sizeof(OVERLAPPED));	

	char *tempstr = (char*)buf;
	DWORD templen = strlen(tempstr);
	//check params ********************************
	if (buf == NULL || templen == 0)
	{
		setError("<Write> Invalid buffer or buffer length.");
		return m_ErrorCode;
	}

	//get usb handle ********************************
	HANDLE mHandle = getHandle();
	if (mHandle == INVALID_HANDLE_VALUE)
	{
		setError("<Write> Invalid handle.");
		return m_ErrorCode;
	}

	//write fp
	mw_EvtOvlp.hEvent = CreateEvent(NULL, TRUE, FALSE, _T("WriteEvent"));
	DWORD rtn =WriteFile(mHandle,buf,dwLen,&dwSize,&mw_EvtOvlp);
	if (!rtn)
	{
		rtn = GetLastError();
		if (rtn != ERROR_IO_PENDING)
		{
			char err[512] = {0};
			sprintf_s(err, "<Write> Create event error (%d).", rtn);
			setError(err);

			//CloseHandle(mHandle);
			CloseHandle(mw_EvtOvlp.hEvent);
			return m_ErrorCode; //Error
		}
	}

	rtn = WaitForSingleObject(mw_EvtOvlp.hEvent,timeout);

	//get result
	while (TRUE)
	{
		rtn = GetOverlappedResult(mHandle,&mw_EvtOvlp,&dwSize,FALSE);
		if (!rtn)
		{
			rtn = GetLastError();
			if (rtn != ERROR_IO_PENDING)
			{
				char err[512] = {0};
				sprintf_s(err, "<Write> GetOverlappedResult error (%d).", rtn);
				setError(err);

				//CloseHandle(mHandle);
				CloseHandle(mw_EvtOvlp.hEvent);
				return m_ErrorCode;
			}
			//IO pending, then wait 100ms
			WaitForSingleObject(mw_EvtOvlp.hEvent,100);
		}
		else
		{
			break; //success
		}        
	}

	//close handles
	//CloseHandle(mHandle);
	CloseHandle(mw_EvtOvlp.hEvent);
	return dwSize;
}


// L"1234"  ->  "1234"
DWORD CoreFunc::uUnicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte)
{
	if (lpWideCharStr == NULL || ccWideChar < 1)
		return 0;

	return WideCharToMultiByte(CP_UTF8, 0, lpWideCharStr, ccWideChar, lpMuttiByteStr, cbMultiByte, NULL, 0);
}

// 313233  ->  "123"
DWORD CoreFunc::uStrToHexArray(LPVOID inBuf, LPVOID outBuf)
{
	DWORD len = strlen( (char*)inBuf );
	byte *ibuf = (byte*)inBuf;
	byte *oBuf = (byte*)outBuf;
	// shield
	if ( ((len&0x01) == 1) || inBuf == NULL || outBuf == NULL)
		return 0;

	CHAR temp = 0;
	DWORD index = 0;
	byte hextemp = 0;
	for (WORD i=0; i<len; i++)
	{
		hextemp = ibuf[i];
		if (hextemp >= 'a' && hextemp <= 'f')
			hextemp = hextemp - 'a' + 10;
		if (hextemp >= 'A' && hextemp <= 'F')
			hextemp = hextemp - 'A' + 10;
		if (hextemp >= '0' && hextemp <= '9')
			hextemp = hextemp - '0';

		if ( 0 == (i&0x1) )//even
		{
			temp = 0;
			temp = hextemp << 4;
		}
		else
		{//odd
			temp += hextemp;
			oBuf[index++] = temp;
		}
	}
	return index;
}

// "1234"  ->  L"1234"
DWORD CoreFunc::uUtf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar)
{
	if (lpMuttiByteStr == NULL || cbMultiByte < 1)
		return 0;

	return MultiByteToWideChar(CP_UTF8, 0, lpMuttiByteStr, cbMultiByte, lpWideCharStr, ccWideChar);
}
