
#include "stdafx.h"
#include "ComUsbAction.h"


#include "ComLib.h"
#include "ComUsbInfo.h"
#include "ComUsbIo.h"




#include "SetupAPI.h"
#include <initguid.h>
#pragma comment(lib, "SetupApi")

DEFINE_GUID(USB_PRINTER,0x28d78fad, 0x5a12, 0x11D1, 0xae, 0x5b, 0x00, 0x00, 0xf8, 0x03, 0xa8, 0xc2);

static ComLib usblib = ComLib();
static ComUsbInfo usbinfo = ComUsbInfo();
static ComUsbIo usbio = ComUsbIo();

static UsbRegInfo g_usbHeader;
static DWORD g_maxUsb = 0;
static HANDLE g_handle = INVALID_HANDLE_VALUE;

ComUsbAction::ComUsbAction()
{
	memset(&g_usbHeader, 0, sizeof(UsbRegInfo) );
}
ComUsbAction::~ComUsbAction()
{

}


DWORD ComUsbAction::openUsbDevice(DWORD mPortNumber)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	
	CString strPath;	

	//global
	memset( &g_usbHeader, 0, sizeof(UsbRegInfo) );
	g_maxUsb = usbinfo.getUsbInfo(&g_usbHeader);

	DWORD maxUsb = g_maxUsb;
	UsbRegInfo usbHeader = g_usbHeader;
	if (maxUsb == 0)
	{
		return m_ErrorCode;
	}

	//path
	for (DWORD i = 0; i<maxUsb; i++)
	{
		if (mPortNumber == usbHeader.portNumber || mPortNumber == 0)
		{
			strPath.Format( _T("%s"), usbHeader.portPath );
			break;
		}
	}
	if ( strPath.IsEmpty() )
	{
		return m_ErrorCode;
	}
	
	//open device
	HANDLE usbHandle = CreateFile(strPath,
		GENERIC_READ|GENERIC_WRITE, 
		FILE_SHARE_WRITE | FILE_SHARE_READ, 
		NULL, //must be NULL
		OPEN_EXISTING, //must be OPEN_EXISTING
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED , 
		NULL);

	g_handle = usbHandle;
	return 1;
}

void ComUsbAction::closeUsbHandle()
{
	HANDLE handle = g_handle;
	if (handle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(handle);
	}
	g_handle = INVALID_HANDLE_VALUE;
}
