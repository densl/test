
#pragma once

class CoreFunc{
public:
	CoreFunc();
	~CoreFunc();
private:	
	HANDLE g_handle;
	DWORD  g_portIndex;
	char   g_portName[1024];
	CString g_regEnv;

	HANDLE getHandle();
	HANDLE openDevice();

	DWORD getUsbPath(CString& str);	
	DWORD getPortIndex();
	void  setError(char *str);
	DWORD getRegValue(LPCTSTR keyName, LPCTSTR keyValue, LPVOID regValue, DWORD len);
	DWORD getUsbInstance(CString& str);
	DWORD setRegEnv();

public:
	DWORD uGetMaxUsb();
	void  uSetPortIndex(DWORD index);
	DWORD uGetPortNum();
	DWORD uGetPortDesc(CString& str);
public:		
	void  uClose();
	BOOL  uIsAvailable();
	void  uSetPortName(char *portName);

	DWORD uControlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen);
	DWORD uControlIowithTime(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout);
	DWORD uRead(LPVOID buf, DWORD dwLen);
	DWORD uWrite(LPVOID buf, DWORD dwLen);
	DWORD uReadwithTime(LPVOID buf, DWORD dwLen, DWORD timeout);
	DWORD uWritewithTime(LPVOID buf, DWORD dwLen, DWORD timeout);
public:
	DWORD uUnicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte);
	DWORD uStrToHexArray(LPVOID inBuf, LPVOID outBuf);
	DWORD uUtf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar);
};