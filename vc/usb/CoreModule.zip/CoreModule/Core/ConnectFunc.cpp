
#include "stdafx.h"
#include "ConnectFunc.h"


ConnectFunc::ConnectFunc()
{

}
ConnectFunc::~ConnectFunc()
{

}

DWORD ConnectFunc::getMaxUsb()
{
	return uGetMaxUsb();
}
void ConnectFunc::setPortIndex(DWORD index)
{
	uSetPortIndex(index);
}
DWORD ConnectFunc::getPortNumber()
{
	return uGetPortNum();
}
DWORD ConnectFunc::getPortDesc(CString& str)
{
	return uGetPortDesc(str);
}

void ConnectFunc::closePrinter()
{
	uClose();
}
BOOL ConnectFunc::isAvailable()
{
	return uIsAvailable();
}
void ConnectFunc::setPortName(char *portName)
{
	uSetPortName(portName);
}

DWORD ConnectFunc::controlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return uControlIo(dwIoControlCode, inBuf, inLen, outBuf, outLen);
}
DWORD ConnectFunc::controlIowithTime(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout)
{
	return uControlIowithTime(dwIoControlCode, inBuf, inLen, outBuf, outLen, timeout);
}
DWORD ConnectFunc::readBuf(LPVOID buf, DWORD dwLen)
{
	return uRead(buf, dwLen);
}
DWORD ConnectFunc::writeBuf(LPVOID buf, DWORD dwLen)
{
	return uWrite(buf, dwLen);
}
DWORD ConnectFunc::readBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{
	return uReadwithTime(buf, dwLen, timeout);
}
DWORD ConnectFunc::writeBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout)
{
	return uWritewithTime(buf, dwLen, timeout);
}

DWORD ConnectFunc::unicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte)
{
	return uUnicodeToUTF8(lpWideCharStr, ccWideChar, lpMuttiByteStr, cbMultiByte);
}
DWORD ConnectFunc::strToHexArray(LPVOID inBuf, LPVOID outBuf)
{
	return uStrToHexArray(inBuf, outBuf);
}
DWORD ConnectFunc::utf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar)
{
	return uUtf8ToUnicode(lpMuttiByteStr, cbMultiByte, lpWideCharStr, ccWideChar);
}


//########################################################################################################################
//########################################################################################################################
//for easy
DWORD ConnectFunc::enumPrinter(CString& str)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	DWORD maxUsbNum = getMaxUsb();
	if (maxUsbNum == 0)
	{
		return m_ErrorCode;
	}

	str.Format(_T("%-4d"), maxUsbNum);

	CString temp;
	DWORD portnum = 0;
	CString desc;
	for (DWORD i = 0; i<maxUsbNum; i++)
	{
		setPortIndex(i);
		portnum = getPortNumber();
		getPortDesc(desc);
		temp = _T("#");
		temp += desc;
		desc.Format(_T("@USB%03d"), portnum);
		str += temp+desc;
	}

	return maxUsbNum;
}
byte  ConnectFunc::getStdStatus()
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	byte statusCode = 0;

	ret = controlIo( IOCTL_USBPRINT_GET_LPT_STATUS, NULL, 0, &statusCode, sizeof(statusCode) );

	return statusCode;
}
DWORD ConnectFunc::getStdId(CString& str)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	char buf[4096] = {0};
	memset(buf, 0, 4096);
	ret = controlIo( IOCTL_USBPRINT_GET_1284_ID, NULL, 0, buf, 4096 );
	if (ret == 0)
		return m_ErrorCode;

	if (ret > strlen(buf))
		fillEmpty(buf, ret);

	str.Format(_T("%S"), buf);
	return ret;
}

DWORD ConnectFunc::sendData(char *buf)
{
	DWORD m_ErrorCode = 0;
	DWORD len = strlen(buf);
	if (buf == NULL || len == 0 )
	{
		return m_ErrorCode;
	}

	return writeBuf(buf, len);
}
DWORD ConnectFunc::sendDataLen(char *buf, DWORD len)
{
	DWORD m_ErrorCode = 0;
	if (buf == NULL || len == 0 )
	{
		return m_ErrorCode;
	}

	return writeBuf(buf, len);
}
DWORD ConnectFunc::sendCmd(char *buf)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	DWORD len = strlen(buf);
	if (buf == NULL || len == 0)
	{
		return m_ErrorCode;
	}

	char *cmdBuf = new char[len];
	memset(cmdBuf, 0, len);

	ret = strToHexArray(buf, cmdBuf);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return writeBuf(cmdBuf, ret);
}
DWORD ConnectFunc::sendCmdLen(char *buf, DWORD cmdLen)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	DWORD len = strlen(buf);
	if (buf == NULL || len == 0)
	{
		return m_ErrorCode;
	}

	char *cmdBuf = new char[len];
	memset(cmdBuf, 0, len);

	ret = strToHexArray(buf, cmdBuf);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	len = strlen(cmdBuf);
	return writeBuf(cmdBuf, cmdLen);
}


DWORD ConnectFunc::recvBuf(char *buf, DWORD timeout)
{
	return readBufwithTime(buf, 4096, timeout);
}
DWORD ConnectFunc::recvBufLen(char *buf, DWORD len, DWORD timeout)
{
	return readBufwithTime(buf, len, timeout);
}

DWORD ConnectFunc::recvString(CString& str, DWORD times)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	char buf[4096];
	memset(buf, 0, 4096);

	ret = readBufwithTime(buf, 4096, times);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	if (ret > strlen(buf))
		fillEmpty(buf, ret);

	str.Format(_T("%S"), buf);
	return ret;
}
DWORD ConnectFunc::recvBarCode(CString& str, DWORD times)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	CStringA stra;
	char buf[4096];
	memset(buf, 0, 4096);

	ret = recvBuf(buf, times);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	stra = buf;
	if (stra.Find("SRD") > 0)
	{
		stra = buf+6;
		TCHAR outBuf[4096];
		memset(outBuf, 0, sizeof(TCHAR) * 4096);

		ret = utf8ToUnicode(buf+6, 4000, outBuf, 4096);
		str = outBuf;
		return ret;
	}

	return m_ErrorCode;
}


DWORD ConnectFunc::getVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return controlIo(IOCTL_USBPRINT_VENDOR_GET_COMMAND, inBuf, inLen,outBuf, outLen);
}
DWORD ConnectFunc::setVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen)
{
	return controlIo(IOCTL_USBPRINT_VENDOR_SET_COMMAND, inBuf, inLen, outBuf, outLen);
}




//common functions
//  "12\x00k"  --> "12 k"
DWORD ConnectFunc::fillEmpty(char *buf, DWORD len)
{
	DWORD count = 0;
	for (DWORD i=0; i<len; i++)
	{
		if (buf[i] == 0)
		{
			buf[i] = 0x20;
			count++;
		}
	}
	return count;
}