
#pragma once

class ComUsbAction{
public:
	ComUsbAction();
	~ComUsbAction();
private:
	void closeUsbHandle();
	DWORD openUsbDevice(DWORD mPortNumber);
	
};