
#include "stdafx.h"
#include "ComUsbInfo.h"

#include "SetupAPI.h"
#include <initguid.h>
#pragma comment(lib, "SetupApi")

#define CHECK_ERROR		if (ret == 0) return m_ErrorCode;
#define BUF_LEN 1024



DEFINE_GUID(USB_PRINTER,0x28d78fad, 0x5a12, 0x11D1, 0xae, 0x5b, 0x00, 0x00, 0xf8, 0x03, 0xa8, 0xc2);

static UsbRegInfo header;
static CString g_regEnv;
static DWORD getRegValue(LPCTSTR keyName, LPCTSTR keyValue, LPVOID regValue, DWORD len);
static DWORD getInstance(CString& str, DWORD index);

static DWORD getMaxUsb();
static DWORD setRegEnv(DWORD index);
static DWORD getPortInstance(TCHAR* str);
static DWORD getPortPath(TCHAR* str);
static DWORD getPortDesc(TCHAR* str);
static DWORD getPortNum();
static DWORD getPidVid(DWORD &vid, DWORD &pid);


ComUsbInfo::ComUsbInfo()
{
	memset( &header, 0, sizeof(UsbRegInfo) );
}
ComUsbInfo::~ComUsbInfo()
{
	releaseUsbInfo();
}

DWORD ComUsbInfo::getUsbInfo(UsbRegInfo *mUsbRegInfo){
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	if (mUsbRegInfo == NULL)
	{
		return m_ErrorCode;
	}

	//max usb count
	DWORD maxUsb = getMaxUsb();
	if (maxUsb == 0)
	{
		return m_ErrorCode;
	}

	UsbRegInfo *rtnData;
	UsbRegInfo *temp;	
	temp = &header;
	memset( temp, 0, sizeof(UsbRegInfo) );
	for (DWORD i = 0; i<maxUsb; i++)
	{
		ret = setRegEnv(i);
		CHECK_ERROR;

		temp->index = i;

		ret = getPortNum();
		CHECK_ERROR;
		temp->portNumber = ret;

		DWORD v = 0;
		DWORD p = 0;
		ret = getPidVid(v, p);
		CHECK_ERROR;
		temp->vid = v;
		temp->pid = p;

		ret = getPortInstance(temp->portInstance);
		CHECK_ERROR;

		ret = getPortDesc(temp->portDesc);
		CHECK_ERROR;

		ret = getPortPath(temp->portPath);
		CHECK_ERROR;


		if (temp->index + 1 == maxUsb)
		{
			temp->next = NULL;
		}
		else
		{//next
			rtnData = temp;
			temp = (UsbRegInfo *)malloc( sizeof(UsbRegInfo) );
			memset( temp, 0, sizeof(UsbRegInfo) ); 
			rtnData->next = temp;
		}
	}// end for loop

	*mUsbRegInfo = header;
	return maxUsb;
}
void ComUsbInfo::releaseUsbInfo()
{
	UsbRegInfo *temp = header.next;
	UsbRegInfo *nextTemp = NULL;

	while (temp != NULL)
	{
		nextTemp = temp->next;
		free(temp);
		temp = nextTemp;
	}

	header.next = NULL;
}


static DWORD getRegValue(LPCTSTR keyName, LPCTSTR keyValue, LPVOID regValue, DWORD len)
{	
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	//open enum key
	HKEY hKey;
	ret = RegOpenKeyExW(HKEY_LOCAL_MACHINE,keyName,0,KEY_READ,&hKey);
	if( ERROR_SUCCESS !=  ret)
	{
		return m_ErrorCode;
	}

	//get usb printer count
	DWORD retLen = len;
	ret = RegQueryValueExW(hKey,keyValue,NULL,NULL,(BYTE*)regValue,&retLen);
	RegCloseKey(hKey);
	if( ERROR_SUCCESS != ret)
	{	
		return m_ErrorCode;
	}

	return retLen;
}
static DWORD getInstance(CString& str, DWORD index)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	TCHAR *keyName = _T("SYSTEM\\CurrentControlSet\\Services\\usbprint\\Enum");
	CString strIndex; //saved index
	strIndex.Format(_T("%d"), index);

	TCHAR strInstance[MAX_PATH];
	DWORD retLen = MAX_PATH * sizeof(TCHAR);
	memset(strInstance, 0, retLen);

	ret = getRegValue(keyName, strIndex, strInstance, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	str = strInstance;
	return ret;
}

static DWORD getMaxUsb()
{	
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	TCHAR *keyName = _T("SYSTEM\\CurrentControlSet\\Services\\usbprint\\Enum");
	TCHAR *keyValue = _T("Count");
	DWORD maxNum = 0;
	DWORD len = sizeof(DWORD);

	ret = getRegValue(keyName, keyValue, &maxNum, len);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return maxNum;
}
static DWORD setRegEnv(DWORD index)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	CString mInstance;
	ret = getInstance(mInstance, index);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	mInstance.Replace(_T('\\'), _T('#'));
	CString strTpl = _T("##?#replacement#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}");
	strTpl.Replace(_T("replacement"), mInstance);


	g_regEnv = _T("SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\{28d78fad-5a12-11d1-ae5b-0000f803a8c2}\\")+strTpl;
	return ret;
}
static DWORD getPortInstance(TCHAR *str)
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv;
	TCHAR *keyValue = _T("DeviceInstance");

	DWORD retLen = BUF_LEN * sizeof(TCHAR);
	ret = getRegValue(keyName, keyValue, str, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	return ret;
}
static DWORD getPortPath(TCHAR* str)
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#");
	TCHAR *keyValue = _T("SymbolicLink");

	DWORD retLen = BUF_LEN * sizeof(TCHAR);
	ret = getRegValue(keyName, keyValue, str, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return ret;
}
static DWORD getPortDesc(TCHAR* str)
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#\\Device Parameters");
	TCHAR *keyValue = _T("Port Description");

	DWORD retLen = BUF_LEN * sizeof(TCHAR);
	ret = getRegValue(keyName, keyValue, str, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return ret;
}
static DWORD getPortNum()
{
	BOOL m_ErrorCode = FALSE;
	DWORD ret = 0;

	CString keyName = g_regEnv + _T("\\#\\Device Parameters");
	TCHAR *keyValue = _T("Port Number");

	DWORD portNum = 0;
	DWORD retLen = sizeof(DWORD);


	ret = getRegValue(keyName, keyValue, &portNum, retLen);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	return portNum;
}
static DWORD getPidVid(DWORD &vid, DWORD &pid)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	CString ins;
	CString pidStr;
	CString vidStr;

	ins = g_regEnv;
	int pos = ins.Find(_T("VID_"));
	if (pos < 0)
	{
		return m_ErrorCode;
	}
	vidStr = ins.Mid(pos+4, 4);

	pos = ins.Find(_T("PID_"));
	if (pos < 0)
	{
		return m_ErrorCode;
	}
	pidStr = ins.Mid(pos+4, 4);

	swscanf_s(vidStr, _T("%X"), &vid);
	swscanf_s(pidStr, _T("%X"), &pid);

	return 1;
}




