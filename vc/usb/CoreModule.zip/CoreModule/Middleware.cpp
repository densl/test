
#include "stdafx.h"
#include "Middleware.h"


Middleware::Middleware()
{

}

Middleware::~Middleware()
{

}

DWORD Middleware::enumPrinter(CString& str)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	DWORD maxUsbNum = getMaxUsb();
	if (maxUsbNum == 0)
	{
		return m_ErrorCode;
	}

	str.Format(_T("%-4d"), maxUsbNum);

	CString temp;
	DWORD portnum = 0;
	CString desc;
	for (DWORD i = 0; i<maxUsbNum; i++)
	{
		setPortIndex(i);
		portnum = getPortNum();
		getPortDesc(desc);
		temp = _T("#");
		temp += desc;
		desc.Format(_T("@USB%03d#"), portnum);
		str += temp+desc;
	}

	return maxUsbNum;
}
DWORD Middleware::sendData(char *buf)
{
	DWORD m_ErrorCode = 0;
	DWORD len = strlen(buf);
	if (buf == NULL || len == 0 )
	{
		return m_ErrorCode;
	}

	return uWrite(buf, len);
}
DWORD Middleware::sendCmd(char *buf)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	DWORD len = strlen(buf);
	if (buf == NULL || len == 0)
	{
		return m_ErrorCode;
	}

	char *cmdBuf = new char[len];
	memset(cmdBuf, 0, len);

	ret = strToHexArray(buf, cmdBuf);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	len = strlen(cmdBuf);
	return uWrite(cmdBuf, len);
}
byte  Middleware::getStdStatus()
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;
	byte statusCode = 0;

	ret = uControlIo( IOCTL_USBPRINT_GET_LPT_STATUS, NULL, 0, &statusCode, sizeof(statusCode) );

	return statusCode;
}

DWORD Middleware::recvBuf(char *buf, DWORD times)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	memset(buf, 0, 4096);
	do 
	{
		ret = uRead(buf, 4096);
		if (ret > 0)
		{
			return ret;
		}
		//error
		if ( !isAvailable())
		{
			return m_ErrorCode;
		}
	} while (times--);

	return m_ErrorCode;
}

DWORD Middleware::recvString(CString& str, DWORD times)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	char buf[4096];
	memset(buf, 0, 4096);

	ret = recvBuf(buf, times);
	if (ret == 0)
	{
		return m_ErrorCode;
	}
	str.Format(_T("%S"), buf);

	return ret;
}

DWORD Middleware::recvBarCode(CString& str, DWORD times)
{
	DWORD m_ErrorCode = 0;
	DWORD ret = 0;

	CStringA stra;
	char buf[4096];
	memset(buf, 0, 4096);

	ret = recvBuf(buf, times);
	if (ret == 0)
	{
		return m_ErrorCode;
	}

	stra = buf;
	if (stra.Compare("\x1dSRD ") != 0)
	{
		return m_ErrorCode;
	}
	stra = buf+6;
	str.Format(_T("%S"), buf+6);

	return ret;
}