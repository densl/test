
#pragma once
#include "Core/ConnectFunc.h"


class ComLogic{
public:
	ComLogic();
	~ComLogic();
	ConnectFunc mLogic;
public:
	//basic function
	DWORD getMaxUsb();
	void  setPortIndex(DWORD index);
	DWORD getPortNumber();
	DWORD getPortDesc(CString& str);

	void  closePrinter();
	BOOL  isPrinterAvailable();
	BOOL  openPrinter(char *portName);	

	DWORD controlIo(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen);
	DWORD controlIowithTime(DWORD dwIoControlCode, LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen, DWORD timeout);
	DWORD readBuf(LPVOID buf, DWORD dwLen);
	DWORD writeBuf(LPVOID buf, DWORD dwLen);
	DWORD readBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout);
	DWORD writeBufwithTime(LPVOID buf, DWORD dwLen, DWORD timeout);

	DWORD unicodeToUTF8(LPCWSTR lpWideCharStr, int ccWideChar, LPSTR lpMuttiByteStr, int cbMultiByte);
	DWORD strToHexArray(LPVOID inBuf, LPVOID outBuf);
	DWORD utf8ToUnicode(LPSTR lpMuttiByteStr, int cbMultiByte, LPWSTR lpWideCharStr, int ccWideChar);

	//
	DWORD enumPrinter(CString& str);
	byte  getStdStatus();
	DWORD getStdId(CString& str);

	DWORD sendData(char *buf);
	DWORD sendCmd(char *buf);
	DWORD sendCmdLen(char *buf, DWORD cmdLen);
	DWORD sendDataLen(char *buf, DWORD len);

	DWORD recvBuf(char *buf, DWORD timeout);
	DWORD recvBufLen(char *buf, DWORD len, DWORD timeout);


	DWORD recvString(CString& str, DWORD times);
	DWORD recvBarCode(CString& str, DWORD times);

	DWORD getVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen);
	DWORD setVendorIo(LPVOID inBuf, DWORD inLen, LPVOID outBuf, DWORD outLen);

	//common functions
	DWORD fillEmpty(char *buf, DWORD len);
};